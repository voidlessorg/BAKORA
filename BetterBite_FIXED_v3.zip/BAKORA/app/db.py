import sqlite3, json
from pathlib import Path
from datetime import datetime

BASE = Path(__file__).resolve().parent.parent
DATA = BASE / "data"
DB = DATA / "bakora.db"
DATA.mkdir(exist_ok=True)

def conn():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    return c

def init():
    c=conn()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS settings(
      key TEXT PRIMARY KEY, value TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS customers(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL, phone TEXT DEFAULT '', address TEXT DEFAULT '',
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS products(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL, category TEXT DEFAULT 'شیرینی',
      unit TEXT DEFAULT 'عدد', price REAL NOT NULL DEFAULT 0,
      cost REAL NOT NULL DEFAULT 0, weight REAL DEFAULT 0,
      active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS ingredients(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL, unit TEXT NOT NULL DEFAULT 'گرم',
      price REAL NOT NULL DEFAULT 0, quantity REAL NOT NULL DEFAULT 1,
      updated_at TEXT NOT NULL,
      pricing_mode TEXT NOT NULL DEFAULT 'auto',
      manual_price REAL DEFAULT 0,
      auto_price REAL DEFAULT 0,
      price_source TEXT DEFAULT '',
      price_updated_at TEXT DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS recipes(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL, product_type TEXT DEFAULT 'کوکی',
      yield_count REAL DEFAULT 1, yield_weight REAL DEFAULT 0,
      target_weight REAL DEFAULT 0, profit_percent REAL DEFAULT 0,
      profit_amount REAL DEFAULT 0, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS recipe_items(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      recipe_id INTEGER NOT NULL, ingredient_id INTEGER NOT NULL,
      amount REAL NOT NULL,
      FOREIGN KEY(recipe_id) REFERENCES recipes(id) ON DELETE CASCADE,
      FOREIGN KEY(ingredient_id) REFERENCES ingredients(id)
    );
    CREATE TABLE IF NOT EXISTS orders(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      invoice_no TEXT NOT NULL UNIQUE,
      customer_id INTEGER,
      customer_name TEXT DEFAULT '', customer_phone TEXT DEFAULT '',
      customer_address TEXT DEFAULT '',
      items_json TEXT NOT NULL,
      subtotal REAL NOT NULL DEFAULT 0,
      discount REAL NOT NULL DEFAULT 0,
      total REAL NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'ثبت شده',
      ignored INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      FOREIGN KEY(customer_id) REFERENCES customers(id)
    );
    """)
    defaults={
      "shop_name":"BetterBite","shop_phone":"","shop_address":"",
      "logo":"/static/bakora-logo.png","currency":"تومان",
      "gemini_key":"","invoice_footer":"از خرید شما سپاسگزاریم",
      "printer_name":"","print_paper":"A4","print_bw":"1"
    }
    for k,v in defaults.items():
        c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)",(k,v))
    # Safe migrations for databases created by older BAKORA builds.
    cols={r[1] for r in c.execute("PRAGMA table_info(ingredients)").fetchall()}
    for name,typ,default in [
        ("pricing_mode","TEXT NOT NULL DEFAULT 'auto'",None),
        ("manual_price","REAL DEFAULT 0",None),
        ("auto_price","REAL DEFAULT 0",None),
        ("price_source","TEXT DEFAULT ''",None),
        ("price_updated_at","TEXT DEFAULT ''",None)
    ]:
        if name not in cols:
            c.execute(f"ALTER TABLE ingredients ADD COLUMN {name} {typ}")
    c.commit(); c.close()

def rows(q,args=()):
    c=conn(); r=[dict(x) for x in c.execute(q,args).fetchall()]; c.close(); return r
def one(q,args=()):
    c=conn(); x=c.execute(q,args).fetchone(); c.close(); return dict(x) if x else None
def execq(q,args=()):
    c=conn(); cur=c.execute(q,args); c.commit(); last=cur.lastrowid; c.close(); return last

init()
