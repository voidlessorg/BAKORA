from fastapi import FastAPI, Request, UploadFile, File, HTTPException
from fastapi.responses import HTMLResponse, FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from pathlib import Path
from datetime import datetime, timedelta
import json, os, subprocess, tempfile, shutil, re, html, sys
import requests
from urllib.parse import quote_plus
from bs4 import BeautifulSoup
import statistics

from . import db

BASE=Path(__file__).resolve().parent.parent
STATIC=BASE/"app"/"static"
UPLOADS=BASE/"uploads"
DATA=BASE/"data"

# Create runtime folders automatically so the app works after ZIP extraction.
STATIC.mkdir(parents=True, exist_ok=True)
UPLOADS.mkdir(parents=True, exist_ok=True)
DATA.mkdir(parents=True, exist_ok=True)

app=FastAPI(title="BAKORA")
app.mount("/static", StaticFiles(directory=STATIC), name="static")
app.mount("/uploads", StaticFiles(directory=UPLOADS), name="uploads")

def now(): return datetime.now().isoformat(timespec="seconds")
def settings():
    return {x["key"]:x["value"] for x in db.rows("SELECT key,value FROM settings")}
def money(x):
    try: return round(float(x or 0))
    except (TypeError, ValueError): return 0
def num(x,default=0.0):
    try: return float(x)
    except (TypeError, ValueError): return default
PRICE_SOURCES_DEFAULT = [
    {"name":"Kitline", "url":"https://kitline.com/?s={query}", "enabled":True},
    {"name":"ParsKakShop", "url":"https://www.parskakshop.ir/?s={query}&post_type=product", "enabled":True},
    {"name":"Foodoko", "url":"https://foodoko.ir/?s={query}", "enabled":True},
]

def gemini_proxy_settings(s):
    # Proxy is intentionally used ONLY for Gemini API requests.
    p=(s.get("gemini_proxy") or "").strip()
    if not p: return None
    if "://" not in p: p="socks5h://"+p
    return {"http":p,"https":p}

def fa_num(v):
    trans=str.maketrans("۰۱۲۳۴۵۶۷۸۹٬", "0123456789,")
    x=str(v).translate(trans).replace(",", "").replace("٬", "")
    try: return float(re.sub(r"[^0-9.]", "", x))
    except: return None

def normalize_price_to_unit(price, text, unit):
    # Price normalization is intentionally conservative; it handles common g/kg/ml/l and piece labels.
    if price is None: return None
    t=text.replace("،",",").replace("٬",",").lower()
    qty=None
    m=re.search(r"(\d+(?:[.,]\d+)?)\s*(کیلوگرم|کیلو|kg|گرم|g|میلی.?لیتر|ml|لیتر|l)",t)
    if m:
        q=float(m.group(1).replace(',','.')); u=m.group(2)
        if u in ('کیلوگرم','کیلو','kg'): qty=q*1000
        elif u in ('گرم','g'): qty=q
        elif u in ('لیتر','l'): qty=q*1000
        elif u in ('میلی لیتر','میلی‌لیتر','ml'): qty=q
    if qty and unit in ('گرم','g','میلی‌لیتر','ml'):
        return price/qty
    if qty and unit in ('کیلو','کیلوگرم','kg'):
        return price/(qty/1000)
    if qty and unit in ('لیتر','l'):
        return price/(qty/1000)
    return price

def scrape_source(url, query):
    try:
        r=requests.get(url.format(query=quote_plus(query)), headers={"User-Agent":"Mozilla/5.0 BetterBitePriceBot/1.0"}, timeout=18, )
        r.raise_for_status()
        soup=BeautifulSoup(r.text,"html.parser")
        out=[]
        for node in soup.select(".price, .woocommerce-Price-amount, [class*=price], [itemprop=price], meta[itemprop=price]"):
            raw=node.get("content") or node.get_text(" ",strip=True)
            p=fa_num(raw)
            if p and 100 <= p <= 500_000_000:
                out.append((p, node.parent.get_text(" ",strip=True)[:220] if node.parent else raw))
        # JSON-LD fallback
        for sc in soup.select('script[type="application/ld+json"]'):
            try:
                obj=json.loads(sc.string or "{}")
                objs=obj if isinstance(obj,list) else [obj]
                for o in objs:
                    offers=o.get("offers") if isinstance(o,dict) else None
                    offers=offers if isinstance(offers,list) else [offers]
                    for off in offers:
                        if isinstance(off,dict):
                            p=fa_num(off.get("price"))
                            if p: out.append((p, str(o.get("name",query))))
            except: pass
        return out[:60]
    except Exception as e:
        return []

def common_price(values):
    vals=sorted(v for v in values if v and v>0)
    if not vals: return None
    med=statistics.median(vals)
    # Remove extreme points relative to median; Iran pricing varies, so use a wide band.
    core=[v for v in vals if med*0.35 <= v <= med*2.8]
    if not core: core=vals
    # Round into practical price buckets and select the densest bucket, then median of that bucket.
    step=max(1000, round(statistics.median(core)/100)*100)
    buckets={}
    for v in core:
        b=round(v/step)*step; buckets.setdefault(b,[]).append(v)
    best=max(buckets.values(), key=lambda x:(len(x),-abs(statistics.median(x)-med)))
    return round(statistics.median(best))

def need_name(x):
    n=str((x or {}).get("name","")).strip()
    if not n: raise HTTPException(400,"نام الزامی است")
    return n

@app.get("/", response_class=HTMLResponse)
def home():
    return (STATIC/"index.html").read_text(encoding="utf-8")

def public_settings():
    s=settings()
    s["gemini_key_set"]="1" if s.get("gemini_key","").strip() else ""
    s["gemini_key"]=""   # never expose the key to LAN clients
    return s

@app.get("/api/settings")
def get_settings(): return public_settings()

@app.post("/api/settings")
async def save_settings(req: Request):
    data=await req.json()
    c=db.conn()
    for k,v in data.items():
        if k=="gemini_key" and not str(v).strip(): continue   # empty = keep existing
        if k in {"shop_name","shop_phone","shop_address","logo","currency","gemini_key","gemini_proxy","price_sources","invoice_footer","printer_name","print_paper","print_bw"}:
            c.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(k,str(v)))
    c.commit(); c.close()
    return public_settings()

# ---------- Windows service management ----------
SERVICE_NAME = "BetterBiteServer"
SERVICE_SCRIPT = BASE / "windows_service.py"

def _is_windows():
    return os.name == "nt"

def _sc_query():
    if not _is_windows():
        return {"supported": False, "installed": False, "running": False, "state": "Windows only"}
    try:
        p=subprocess.run(["sc.exe", "query", SERVICE_NAME], capture_output=True, text=True, timeout=8)
        out=(p.stdout or "")+(p.stderr or "")
        installed=p.returncode == 0
        running="RUNNING" in out
        state="RUNNING" if running else ("STOPPED" if installed else "NOT_INSTALLED")
        return {"supported":True,"installed":installed,"running":running,"state":state,"detail":out[-1500:]}
    except Exception as e:
        return {"supported":True,"installed":False,"running":False,"state":"ERROR","detail":str(e)}

def _service_cmd(command):
    if not _is_windows():
        raise HTTPException(400, "سرویس BetterBite فقط روی Windows قابل استفاده است")
    if not SERVICE_SCRIPT.exists():
        raise HTTPException(500, "فایل سرویس پیدا نشد")
    # Service installation/removal requires an elevated Administrator process.
    args=[sys.executable, str(SERVICE_SCRIPT)] + command.split()
    p=subprocess.run(args, cwd=str(BASE), capture_output=True, text=True, timeout=30)
    detail=((p.stdout or "")+"\n"+(p.stderr or "")).strip()
    if p.returncode != 0:
        raise HTTPException(500, "اجرای سرویس ناموفق بود: "+(detail[-1200:] or "دسترسی Administrator لازم است"))
    return detail

@app.get("/api/service")
def service_status():
    return _sc_query()

@app.post("/api/service/{action}")
def service_action(action:str):
    if action not in {"install","uninstall","start","stop","restart"}:
        raise HTTPException(400,"عملیات سرویس نامعتبر است")
    detail=""
    if action=="install":
        detail=_service_cmd("--startup=auto install")
        # Ensure automatic restart after unexpected crashes.
        try:
            subprocess.run(["sc.exe","failure",SERVICE_NAME,"reset=","86400","actions=","restart/5000/restart/10000/restart/30000"],capture_output=True,text=True,timeout=8)
        except Exception:
            pass
    elif action=="uninstall":
        # Stop first; uninstall then removes the service registration.
        try: subprocess.run(["sc.exe","stop",SERVICE_NAME],capture_output=True,text=True,timeout=10)
        except Exception: pass
        detail=_service_cmd("remove")
    else:
        sc_action={"start":"start","stop":"stop","restart":"stop"}[action]
        if action=="restart":
            subprocess.run(["sc.exe","stop",SERVICE_NAME],capture_output=True,text=True,timeout=15)
            sc_action="start"
        if not _sc_query().get("installed"):
            raise HTTPException(400,"سرویس نصب نیست")
        p=subprocess.run(["sc.exe",sc_action,SERVICE_NAME],capture_output=True,text=True,timeout=15)
        if p.returncode!=0:
            raise HTTPException(500,(p.stdout or "")+(p.stderr or ""))
        detail=(p.stdout or p.stderr or "").strip()
    return {"ok":True,"action":action,"status":_sc_query(),"detail":detail[-2000:]}

@app.post("/api/logo")
async def logo(file: UploadFile=File(...)):
    ext=Path(file.filename or "").suffix.lower()
    if ext not in {".png",".jpg",".jpeg",".webp",".svg"}: raise HTTPException(400,"فرمت لوگو مجاز نیست")
    name="logo"+ext
    (UPLOADS/name).write_bytes(await file.read())
    url=f"/uploads/{name}?v={int(datetime.now().timestamp())}"
    db.execq("INSERT INTO settings(key,value) VALUES('logo',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(url,))
    return {"url":url}

@app.get("/api/products")
def products(): return db.rows("SELECT * FROM products ORDER BY id DESC")
@app.post("/api/products")
async def add_product(req:Request):
    x=await req.json()
    return {"id":db.execq("""INSERT INTO products(name,category,unit,price,cost,weight,active,created_at)
      VALUES(?,?,?,?,?,?,1,?)""",(need_name(x),x.get("category","شیرینی"),x.get("unit","عدد"),num(x.get("price")),num(x.get("cost")),num(x.get("weight")),now()))}
@app.put("/api/products/{pid}")
async def upd_product(pid:int,req:Request):
    x=await req.json()
    db.execq("UPDATE products SET name=?,category=?,unit=?,price=?,cost=?,weight=?,active=? WHERE id=?",
             (need_name(x),x.get("category","شیرینی"),x.get("unit","عدد"),num(x.get("price")),num(x.get("cost")),num(x.get("weight")),1 if x.get("active",1) else 0,pid))
    return {"ok":True}
@app.delete("/api/products/{pid}")
def del_product(pid:int): db.execq("DELETE FROM products WHERE id=?",(pid,)); return {"ok":True}

@app.get("/api/customers")
def customers(): return db.rows("SELECT * FROM customers ORDER BY id DESC")
@app.post("/api/customers")
async def add_customer(req:Request):
    x=await req.json()
    return {"id":db.execq("INSERT INTO customers(name,phone,address,created_at) VALUES(?,?,?,?)",
                           (need_name(x),x.get("phone",""),x.get("address",""),now()))}
@app.put("/api/customers/{cid}")
async def upd_customer(cid:int,req:Request):
    x=await req.json()
    db.execq("UPDATE customers SET name=?,phone=?,address=? WHERE id=?",(need_name(x),x.get("phone",""),x.get("address",""),cid))
    return {"ok":True}
@app.delete("/api/customers/{cid}")
def del_customer(cid:int):
    c=db.conn()
    c.execute("UPDATE orders SET customer_id=NULL WHERE customer_id=?",(cid,))
    c.execute("DELETE FROM customers WHERE id=?",(cid,)); c.commit(); c.close()
    return {"ok":True}
@app.get("/api/customers/{cid}/orders")
def customer_orders(cid:int): return db.rows("SELECT * FROM orders WHERE customer_id=? ORDER BY id DESC",(cid,))

@app.get("/api/ingredients")
def ingredients(): return db.rows("SELECT * FROM ingredients ORDER BY name")
@app.post("/api/ingredients")
async def add_ingredient(req:Request):
    x=await req.json()
    price=num(x.get("price"))
    mode=x.get("pricing_mode","manual" if price else "auto")
    return {"id":db.execq("""INSERT INTO ingredients(name,unit,price,quantity,updated_at,pricing_mode,manual_price,auto_price,price_source,price_updated_at)
                           VALUES(?,?,?,?,?,?,?,?,?,?)""",
                           (need_name(x),x.get("unit","گرم"),price,max(num(x.get("quantity"),1),0.000001),now(),mode,price if mode=="manual" else 0,price if mode=="auto" else 0,"manual" if mode=="manual" else "",now() if price else ""))}
@app.put("/api/ingredients/{iid}")
async def upd_ingredient(iid:int,req:Request):
    x=await req.json()
    cur=db.one("SELECT * FROM ingredients WHERE id=?",(iid,))
    if not cur: raise HTTPException(404,"ماده اولیه پیدا نشد")
    mode=x.get("pricing_mode",cur.get("pricing_mode","auto"))
    price=num(x.get("price"))
    db.execq("UPDATE ingredients SET name=?,unit=?,price=?,quantity=?,updated_at=?,pricing_mode=?,manual_price=?,auto_price=?,price_source=?,price_updated_at=? WHERE id=?",
             (need_name(x),x.get("unit","گرم"),price,max(num(x.get("quantity"),1),0.000001),now(),mode,price if mode=="manual" else cur.get("manual_price",0),price if mode=="auto" else cur.get("auto_price",0),x.get("price_source",cur.get("price_source","")),now() if mode=="auto" else cur.get("price_updated_at",""),iid))
    return {"ok":True}
@app.delete("/api/ingredients/{iid}")
def del_ingredient(iid:int):
    if db.one("SELECT 1 x FROM recipe_items WHERE ingredient_id=?",(iid,)):
        raise HTTPException(400,"این ماده در دستورها استفاده شده و قابل حذف نیست")
    db.execq("DELETE FROM ingredients WHERE id=?",(iid,)); return {"ok":True}

@app.get("/api/recipes")
def recipes():
    out=[]
    for r in db.rows("SELECT * FROM recipes ORDER BY id DESC"):
        r["items"]=db.rows("""SELECT ri.*,i.name,i.unit,i.price,i.quantity FROM recipe_items ri
                              JOIN ingredients i ON i.id=ri.ingredient_id WHERE recipe_id=?""",(r["id"],))
        r["ingredient_cost"]=sum(num(i["amount"])*num(i["price"])/max(num(i["quantity"],1),0.000001) for i in r["items"])
        yc=max(num(r["yield_count"],1),1)
        # if total weight and per-piece weight are given, the real piece count follows from them
        if num(r["yield_weight"])>0 and num(r["target_weight"])>0:
            yc=max(num(r["yield_weight"])/num(r["target_weight"]),1)
        r["pieces"]=yc
        r["cost_per_unit"]=r["ingredient_cost"]/yc
        r["suggested_price"]=r["cost_per_unit"]*(1+num(r["profit_percent"])/100)+num(r["profit_amount"])
        out.append(r)
    return out

@app.post("/api/recipes")
async def add_recipe(req:Request):
    x=await req.json()
    c=db.conn()
    cur=c.execute("""INSERT INTO recipes(name,product_type,yield_count,yield_weight,target_weight,profit_percent,profit_amount,created_at)
                    VALUES(?,?,?,?,?,?,?,?)""",(need_name(x),x.get("product_type","کوکی"),max(num(x.get("yield_count"),1),1),num(x.get("yield_weight")),
                    num(x.get("target_weight")),num(x.get("profit_percent")),num(x.get("profit_amount")),now()))
    rid=cur.lastrowid
    for i in x.get("items",[]):
        c.execute("INSERT INTO recipe_items(recipe_id,ingredient_id,amount) VALUES(?,?,?)",(rid,int(i["ingredient_id"]),num(i["amount"])))
    c.commit(); c.close()
    return {"id":rid}

@app.delete("/api/recipes/{rid}")
def del_recipe(rid:int):
    c=db.conn()
    c.execute("DELETE FROM recipe_items WHERE recipe_id=?",(rid,))
    c.execute("DELETE FROM recipes WHERE id=?",(rid,)); c.commit(); c.close()
    return {"ok":True}

@app.post("/api/recipes/{rid}/to-product")
def recipe_to_product(rid:int):
    r=next((x for x in recipes() if x["id"]==rid),None)
    if not r: raise HTTPException(404,"دستور پیدا نشد")
    pid=db.execq("""INSERT INTO products(name,category,unit,price,cost,weight,active,created_at)
      VALUES(?,?,?,?,?,?,1,?)""",(r["name"],r["product_type"] or "کوکی","عدد",round(r["suggested_price"]),round(r["cost_per_unit"]),num(r["target_weight"]),now()))
    return {"id":pid}

@app.get("/api/orders")
def orders():
    return db.rows("SELECT * FROM orders ORDER BY id DESC")
@app.post("/api/orders")
async def add_order(req:Request):
    x=await req.json()
    invoice=f"F-{datetime.now().strftime('%Y%m%d')}-{db.one('SELECT COALESCE(MAX(id),0)+1 n FROM orders')['n']:04d}"
    items=x.get("items",[])
    subtotal=sum(num(i.get("qty"),1)*num(i.get("price")) for i in items)
    discount=max(num(x.get("discount")),0)
    total=max(0,subtotal-discount)
    try: cid=int(x.get("customer_id")) if x.get("customer_id") not in (None,"") else None
    except (TypeError,ValueError): cid=None
    if not items: raise HTTPException(400,"حداقل یک کالا وارد کنید")
    if cid is None and str(x.get("customer_name","")).strip():
        cid=db.execq("INSERT INTO customers(name,phone,address,created_at) VALUES(?,?,?,?)",
                     (x.get("customer_name",""),x.get("customer_phone",""),x.get("customer_address",""),now()))
    oid=db.execq("""INSERT INTO orders(invoice_no,customer_id,customer_name,customer_phone,customer_address,items_json,subtotal,discount,total,status,ignored,created_at)
                    VALUES(?,?,?,?,?,?,?,?,?,'ثبت شده',0,?)""",
                 (invoice,cid,x.get("customer_name",""),x.get("customer_phone",""),x.get("customer_address",""),
                  json.dumps(items,ensure_ascii=False),subtotal,discount,total,now()))
    return {"id":oid,"invoice_no":invoice,"total":total}

@app.post("/api/orders/{oid}/ignore")
def ignore_order(oid:int):
    db.execq("UPDATE orders SET ignored=1,status='نادیده گرفته شد' WHERE id=?",(oid,)); return {"ok":True}

@app.post("/api/orders/{oid}/restore")
def restore_order(oid:int):
    db.execq("UPDATE orders SET ignored=0,status='ثبت شده' WHERE id=?",(oid,)); return {"ok":True}

@app.post("/api/orders/{oid}/status")
async def status_order(oid:int,req:Request):
    x=await req.json(); db.execq("UPDATE orders SET status=? WHERE id=?",(x["status"],oid)); return {"ok":True}

@app.get("/api/reports")
def reports():
    orders=db.rows("SELECT * FROM orders WHERE ignored=0")
    products={p["id"]:p for p in db.rows("SELECT * FROM products")}
    def profit(o):
        cost=0
        try:
            for i in json.loads(o["items_json"]):
                cost += num(i.get("qty"),1)*num(i.get("cost"))
        except: pass
        return num(o["total"])-cost
    data=[]
    for o in orders: data.append({**o,"profit":profit(o)})
    today=datetime.now().date()
    ranges={
      "روز": lambda d:d==today,
      "هفته": lambda d:today-timedelta(days=6)<=d<=today,
      "ماه": lambda d:d.year==today.year and d.month==today.month,
      "کل": lambda d:True
    }
    out={}
    for k,f in ranges.items():
        sel=[x for x in data if f(datetime.fromisoformat(x["created_at"]).date())]
        out[k]={"sales":sum(x["total"] for x in sel),"profit":sum(x["profit"] for x in sel),
                "orders":len(sel),"cost":sum(x["total"]-x["profit"] for x in sel)}
    return out

@app.get("/api/printers")
def printers():
    try:
        import win32print
        flags=win32print.PRINTER_ENUM_LOCAL|win32print.PRINTER_ENUM_CONNECTIONS
        ps=[p[2] for p in win32print.EnumPrinters(flags)]
        return {"printers":ps,"default":win32print.GetDefaultPrinter()}
    except Exception as e:
        return {"printers":[],"default":"","error":str(e)}

def print_opts(paper=None,bw=None):
    s=settings()
    paper=(paper or s.get("print_paper") or "A4").upper()
    if paper not in ("A4","A5"): paper="A4"
    if bw is None or bw=="": bw=s.get("print_bw","1")
    return paper, str(bw) in ("1","true","True")

def make_invoice_html(order,autoprint=False,paper=None,bw=None):
    paper,bw=print_opts(paper,bw)
    s=settings()
    E=lambda v: html.escape(str(v if v is not None else ""))
    try: items=json.loads(order["items_json"])
    except Exception: items=[]
    rows=""
    for n,i in enumerate(items,1):
        rows+=f"<tr><td>{n}</td><td>{E(i.get('name',''))}</td><td>{E(i.get('qty',1))}</td><td>{money(i.get('price',0)):,}</td><td>{money(num(i.get('qty'),1)*num(i.get('price'))):,}</td></tr>"
    logo=E(s.get("logo",""))
    shop=E(s.get("shop_name",""));addr=E(s.get("shop_address",""));ph=E(s.get("shop_phone",""))
    cur=E(s.get("currency","تومان"));foot=E(s.get("invoice_footer",""))
    a5=paper=="A5"
    extra=("body{font-size:11px}.paper{padding:10px}h1{font-size:18px}th,td{padding:4px}table{margin-top:12px}.sum{width:220px}.footer{margin-top:20px}" if a5 else "")
    if bw: extra+="body,.paper,h1,.meta,.sum,td,th{color:#000!important}.top{border-color:#000!important}th,td{border-color:#000!important}th{background:#e8e8e8!important}.logo{filter:grayscale(1) contrast(1.2)}*{-webkit-print-color-adjust:exact;print-color-adjust:exact}"
    script="<script>window.onload=function(){setTimeout(function(){window.print()},400)}</script>" if autoprint else ""
    return f"""<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8">
    <style>@page{{size:{paper};margin:{"6mm" if a5 else "10mm"}}}body{{font-family:Tahoma,Arial,sans-serif;color:#102a63}}.paper{{border:1px solid #ddd;padding:22px}}
    .top{{display:flex;justify-content:space-between;align-items:center;border-bottom:2px solid #102a63;padding-bottom:12px}}
    .logo{{max-width:120px;max-height:70px}}h1{{font-size:24px;margin:0}}.meta{{line-height:2;font-size:13px}}
    table{{width:100%;border-collapse:collapse;margin-top:24px}}th,td{{border:1px solid #6b7da3;padding:8px;text-align:center}}th{{background:#eef2f9}}
    .sum{{margin-top:15px;width:300px;margin-right:auto}}.sum div{{display:flex;justify-content:space-between;padding:5px}}
    .footer{{margin-top:40px;border-top:1px dashed #999;padding-top:12px;display:flex;justify-content:space-between}}{extra}</style></head>
    <body><div class="paper"><div class="top"><div><h1>{shop}</h1><div>{addr}</div><div>{ph}</div></div>
    <img class="logo" src="{logo}"></div><div class="meta"><b>فاکتور فروش</b><br>شماره: {E(order["invoice_no"])} &nbsp; تاریخ: {E(order["created_at"].replace("T"," "))}<br>
    مشتری: {E(order["customer_name"])} &nbsp; تلفن: {E(order["customer_phone"])}<br>آدرس: {E(order["customer_address"])}</div>
    <table><thead><tr><th>ردیف</th><th>شرح کالا / خدمات</th><th>تعداد</th><th>قیمت واحد</th><th>قیمت کل</th></tr></thead><tbody>{rows}</tbody></table>
    <div class="sum"><div><b>جمع کل</b><b>{money(order["subtotal"]):,} {cur}</b></div>
    <div><span>تخفیف</span><span>{money(order["discount"]):,}</span></div><div><b>قابل پرداخت</b><b>{money(order["total"]):,}</b></div></div>
    <div class="footer"><span>امضای مشتری: ................</span><span>امضای فروشنده: ................</span></div>
    <p>{foot}</p></div>{script}</body></html>"""

@app.get("/api/orders/{oid}/invoice")
def invoice(oid:int,print:int=0,paper:str="",bw:str=""):
    o=db.one("SELECT * FROM orders WHERE id=?",(oid,))
    if not o: raise HTTPException(404,"فاکتور پیدا نشد")
    return HTMLResponse(make_invoice_html(o,autoprint=bool(print),paper=paper,bw=bw))

@app.post("/api/orders/{oid}/print")
async def print_order(oid:int,req:Request):
    try: opt=await req.json()
    except Exception: opt={}
    paper=opt.get("paper") if isinstance(opt,dict) else None
    bw=opt.get("bw") if isinstance(opt,dict) else None
    o=db.one("SELECT * FROM orders WHERE id=?",(oid,))
    if not o: raise HTTPException(404,"فاکتور پیدا نشد")
    p=BASE/"data"/f"invoice_{oid}.html"; p.write_text(make_invoice_html(o,paper=paper,bw=bw),encoding="utf-8")
    s=settings()
    pp,pbw=print_opts(paper,bw)
    printer=s.get("printer_name","")
    browser_url=f"/api/orders/{oid}/invoice?print=1&paper={pp}&bw={int(pbw)}"
    if os.name!="nt":
        return {"ok":False,"message":"چاپ مستقیم فقط روی ویندوز میزبان فعال است؛ از چاپ مرورگر استفاده می‌شود.","invoice_url":browser_url}
    # Edge headless -> PDF -> Windows Shell print.
    edge=None
    for candidate in [
      os.environ.get("PROGRAMFILES(X86)","")+r"\Microsoft\Edge\Application\msedge.exe",
      os.environ.get("PROGRAMFILES","")+r"\Microsoft\Edge\Application\msedge.exe"]:
        if os.path.exists(candidate): edge=candidate; break
    if not edge:
        return {"ok":False,"message":"Microsoft Edge پیدا نشد؛ از چاپ مرورگر استفاده کنید.","invoice_url":browser_url}
    pdf=BASE/"data"/f"invoice_{oid}.pdf"
    try:
        subprocess.run([edge,"--headless","--disable-gpu",f"--print-to-pdf={pdf}","--no-pdf-header-footer",p.as_uri()],timeout=30,check=True,
                       stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        import win32api, win32print
        target=printer or win32print.GetDefaultPrinter()
        if printer: win32api.ShellExecute(0,"printto",str(pdf),f'"{printer}"',".",0)
        else: win32api.ShellExecute(0,"print",str(pdf),None,".",0)
        return {"ok":True,"printer":target}
    except Exception as e:
        return {"ok":False,"message":str(e),"invoice_url":browser_url}

@app.post("/api/gemini/update-prices")
async def gemini_prices():
    s=settings(); key=s.get("gemini_key","").strip()
    if not key: raise HTTPException(400,"Gemini API Key در تنظیمات وارد نشده است")
    try: sources=json.loads(s.get("price_sources","") or "")
    except: sources=PRICE_SOURCES_DEFAULT
    sources=[x for x in sources if x.get("enabled",True) and x.get("url")]
    gemini_proxy=gemini_proxy_settings(s)
    ings=db.rows("SELECT * FROM ingredients")
    results=[]
    for ing in ings:
        if ing.get("pricing_mode")=="manual":
            results.append({"id":ing["id"],"name":ing["name"],"old_price":ing["price"],"average_price":None,"common_price":ing["price"],"manual":True,"offers":[],"note":"قیمت دستی؛ بدون تغییر"})
            continue
        offers=[]
        for src in sources:
            for raw,ctx in scrape_source(src["url"],ing["name"]):
                n=normalize_price_to_unit(raw,ctx,ing["unit"])
                if n: offers.append({"source":src["name"],"price":round(n*max(num(ing.get("quantity"),1),0.000001)),"context":ctx})
        # Let Gemini judge the market cluster from real scraped Iranian offers, not invent a price.
        payload={"name":ing["name"],"unit":ing["unit"],"offers":offers[:80]}
        prompt="""تو فقط تحلیلگر قیمت بازار ایران هستی. داده‌های زیر از سایت‌های ایرانی اسکرپ شده‌اند.
قیمت جدید را از خودت اختراع نکن. قیمت رایج را با توجه به خوشه اصلی قیمت‌ها انتخاب کن؛ ارزان‌ترین یا گران‌ترین را معیار نگذار.
اگر داده کافی نیست، common_price را null بده. خروجی فقط JSON: {\"common_price\":number|null,\"confidence\":0..1,\"note\":string}.
"""+json.dumps(payload,ensure_ascii=False)
        try:
            url="https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent"
            r=requests.post(url,params={"key":key},json={"contents":[{"parts":[{"text":prompt}]}],"generationConfig":{"responseMimeType":"application/json"}},timeout=45,)
            r.raise_for_status(); txt=r.json()["candidates"][0]["content"]["parts"][0]["text"]
            ai=json.loads(re.sub(r"^```(?:json)?|```$","",txt.strip(),flags=re.M).strip())
        except Exception as e:
            ai={"common_price":common_price([x["price"] for x in offers]),"confidence":0.35,"note":"Gemini در دسترس نبود؛ قیمت از خوشه قیمت‌های اسکرپ‌شده محاسبه شد."}
        fallback=common_price([x["price"] for x in offers])
        cp=ai.get("common_price") if ai.get("common_price") else fallback
        results.append({"id":ing["id"],"name":ing["name"],"unit":ing["unit"],"old_price":ing["price"],"average_price":cp,"common_price":cp,"confidence":ai.get("confidence",0),"note":ai.get("note",""),"offers":offers,"manual":False})
    return {"items":results,"sources":sources,"proxy_enabled":bool(gemini_proxy)}

@app.post("/api/prices/apply")
async def apply_prices(req:Request):
    data=await req.json(); applied=0
    for it in data.get("items",[]):
        iid=int(it.get("id",0)); p=num(it.get("price"),0)
        if iid and p>0:
            db.execq("UPDATE ingredients SET price=?,auto_price=?,price_source=?,price_updated_at=?,updated_at=?,pricing_mode='auto' WHERE id=?",(p,p,it.get("source","web+gemini"),now(),now(),iid)); applied+=1
    return {"ok":True,"applied":applied}
