/* BAKORA frontend - stable build */
const appEl = document.getElementById('app');
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

let data = {
  settings: {}, products: [], customers: [], ingredients: [], recipes: [], orders: []
};

const fdate = (v) => { try { return new Date(v).toLocaleString('fa-IR'); } catch { return v || ''; } };
const money = (n) => Number(n || 0).toLocaleString('fa-IR');
const esc = (v) => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

async function api(url, options = {}) {
  const opts = { ...options, headers: { ...(options.body instanceof FormData ? {} : {'Content-Type': 'application/json'}), ...(options.headers || {}) } };
  const response = await fetch(url, opts);
  const text = await response.text();
  let payload = {};
  try { payload = text ? JSON.parse(text) : {}; } catch { payload = { detail: text || 'پاسخ نامعتبر از سرور' }; }
  if (!response.ok) throw new Error(payload.detail || payload.message || 'خطا در ارتباط با سرور');
  return payload;
}

async function load() {
  const result = await Promise.all([
    api('/api/settings'),
    api('/api/products'),
    api('/api/customers'),
    api('/api/ingredients'),
    api('/api/recipes'),
    api('/api/orders')
  ]);
  [data.settings, data.products, data.customers, data.ingredients, data.recipes, data.orders] = result;
  const title = document.getElementById('shopTitle');
  if (title) title.textContent = data.settings.shop_name || 'BAKORA';
  const logo = document.getElementById('headerLogo');
  if (logo) logo.src = data.settings.logo || '/static/bakora-logo.png';
}

function show(page) {
  const pages = { dashboard, invoice, products, recipes, ingredients, customers, orders, reports, settings };
  if (!pages[page]) return;
  try { pages[page](); } catch (error) {
    console.error(error);
    appEl.innerHTML = `<div class="card bad"><h3>خطا</h3><p>${esc(error.message)}</p></div>`;
  }
}
window.show = show;

function dashboard(){
  const totalSales=data.orders.filter(o=>!o.ignored).reduce((a,o)=>a+Number(o.total||0),0);
  const openOrders=data.orders.filter(o=>!o.ignored&&o.status!=='تحویل شده').length;
  const low=data.ingredients.filter(i=>Number(i.quantity||0)<=1);
  const best=[...data.products].sort((a,b)=>Number(b.price)-Number(a.price)).slice(0,4);
  appEl.innerHTML=`<div class="dashboard">
    <section class="dash-title"><span class="eyebrow">BetterBite Bakery</span><h1>سلام، وقت‌بخیر 👋</h1><p>مدیریت فروش، مواد اولیه و بهای تمام‌شده در یکجا.</p></section>
    <section><div class="section-title"><h2>عملیات سریع</h2><span>میانبرها</span></div><div class="quick-grid">
      <button class="quick primary" onclick="show('invoice')"><span class="quick-icon material-symbols-outlined">point_of_sale</span><span><b>صدور فاکتور سریع</b><small>ثبت آنی فروش</small></span></button>
      <button class="quick" onclick="show('products')"><span class="quick-icon material-symbols-outlined">bakery_dining</span><span><b>محصولات</b><small>کیک و شیرینی</small></span></button>
      <button class="quick" onclick="show('ingredients')"><span class="quick-icon material-symbols-outlined">inventory_2</span><span><b>مواد اولیه</b><small>قیمت و موجودی</small></span></button>
      <button class="quick" onclick="show('recipes')"><span class="quick-icon material-symbols-outlined">calculate</span><span><b>بهای تمام‌شده</b><small>رسپی و سود</small></span></button>
    </div></section>
    <section><div class="section-title"><h2>شاخص‌های امروز</h2><span>زنده</span></div><div class="metric-grid">
      <div class="metric"><div class="metric-top">فروش ثبت‌شده <span class="metric-icon material-symbols-outlined">payments</span></div><strong>${money(totalSales)}</strong><small>تومان</small></div>
      <div class="metric"><div class="metric-top">فاکتورها <span class="metric-icon material-symbols-outlined">receipt_long</span></div><strong>${data.orders.filter(o=>!o.ignored).length}</strong><small>فاکتور</small></div>
      <div class="metric"><div class="metric-top">سفارش‌های باز <span class="metric-icon material-symbols-outlined">cake</span></div><strong>${openOrders}</strong><small>سفارش</small></div>
      <div class="metric"><div class="metric-top">مواد نیازمند بررسی <span class="metric-icon material-symbols-outlined">warning</span></div><strong>${low.length}</strong><small>قلم</small></div>
    </div></section>
    <section class="panel"><div class="section-title"><h2>قیمت‌گذاری مواد اولیه</h2><span>بازار ایران</span></div><p class="muted">قیمت‌ها از سایت‌های ایرانی جمع می‌شوند؛ قیمت رایج انتخاب می‌شود و قیمت دستی قابل نگه‌داشتن است.</p><button onclick="show('ingredients')">مدیریت و بروزرسانی قیمت‌ها</button></section>
    <section><div class="section-title"><h2>محصولات</h2><span>منو</span></div><div class="list">${best.map(p=>`<div class="list-row"><div><b>${esc(p.name)}</b><div class="sub">${esc(p.category||'محصول')}</div></div><div class="price">${money(p.price)} ت</div></div>`).join('')||'<div class="muted">هنوز محصولی ثبت نشده.</div>'}</div></section>
  </div>`;
}

function invoice() {
  const rows = [{name:'', qty:1, price:0, cost:0}];
  appEl.innerHTML = `
    <div class="invoice">
      <div class="invoice-head">
        <div>
          <h1>${esc(data.settings.shop_name || 'BAKORA')}</h1>
          <div>${esc(data.settings.shop_address || '')}</div>
          <div>${esc(data.settings.shop_phone || '')}</div>
        </div>
        <img class="invoice-logo" src="${esc(data.settings.logo || '/static/bakora-logo.png')}" alt="BAKORA">
      </div>
      <div class="grid" style="margin-top:15px">
        <div class="field"><label>مشتری</label><select id="cust"><option value="">مشتری جدید / بدون ثبت</option>${data.customers.map(c => `<option value="${c.id}">${esc(c.name)} — ${esc(c.phone)}</option>`).join('')}</select></div>
        <div class="field"><label>نام مشتری</label><input id="cn"></div>
        <div class="field"><label>تلفن</label><input id="cp"></div>
        <div class="field"><label>آدرس</label><input id="ca"></div>
      </div>
      <div class="table-wrap">
        <table class="table items"><thead><tr><th>ردیف</th><th>محصول</th><th>تعداد/وزن</th><th>قیمت واحد</th><th>جمع</th><th></th></tr></thead>
        <tbody>${rows.map((r,i) => rowHtml(r,i)).join('')}</tbody></table>
      </div>
      ${printBar()}
      <div class="toolbar no-print">
        <button onclick="addRow()">+ ردیف</button>
        <button onclick="saveInvoice()">ثبت فاکتور</button>
        <button class="secondary" onclick="show('products')">مدیریت محصولات</button>
      </div>
      <div class="total-box">
        <div><span>جمع</span><b id="sum">0</b></div>
        <div><span>تخفیف</span><input id="disc" type="number" value="0" min="0" oninput="calc()"></div>
        <div><span>قابل پرداخت</span><b id="grand">0</b></div>
      </div>
    </div>`;
  calc();
  const customerSelect = document.getElementById('cust');
  customerSelect?.addEventListener('change', () => {
    const c = data.customers.find(x => String(x.id) === String(customerSelect.value));
    if (!c) return;
    document.getElementById('cn').value = c.name || '';
    document.getElementById('cp').value = c.phone || '';
    document.getElementById('ca').value = c.address || '';
  });
}

function rowHtml(r, i) {
  const productOptions = data.products.filter(p => Number(p.active) === 1).map(p =>
    `<option ${p.name === r.name ? 'selected' : ''} value="${p.id}">${esc(p.name)}</option>`
  ).join('');
  return `<tr data-cost="${Number(r.cost || 0)}">
    <td>${i + 1}</td>
    <td><select class="p" onchange="pick(this)"><option value="">انتخاب محصول</option>${productOptions}</select><input class="n" value="${esc(r.name || '')}" placeholder="یا نام دستی"></td>
    <td><input class="q" type="number" value="${Number(r.qty || 1)}" min="0" step="0.01" oninput="calc()"></td>
    <td><input class="pr" type="number" value="${Number(r.price || 0)}" min="0" oninput="calc()"></td>
    <td class="rt">0</td>
    <td><button class="danger" onclick="this.closest('tr').remove();renumberRows();calc()">×</button></td>
  </tr>`;
}

function renumberRows() {
  $$('.items tbody tr').forEach((tr, i) => tr.children[0].textContent = i + 1);
}
window.renumberRows = renumberRows;
window.addRow = () => {
  const tbody = $('.items tbody');
  if (!tbody) return;
  tbody.insertAdjacentHTML('beforeend', rowHtml({qty:1}, tbody.rows.length));
  calc();
};
window.pick = (sel) => {
  const tr = sel.closest('tr');
  const product = data.products.find(p => String(p.id) === String(sel.value));
  if (!product || !tr) return;
  $('.n', tr).value = product.name || '';
  $('.pr', tr).value = Number(product.price || 0);
  tr.dataset.cost = Number(product.cost || 0);
  calc();
};
window.calc = () => {
  let sum = 0;
  $$('.items tbody tr').forEach(tr => {
    const qty = Number($('.q', tr)?.value || 0);
    const price = Number($('.pr', tr)?.value || 0);
    const total = qty * price;
    sum += total;
    const cell = $('.rt', tr);
    if (cell) cell.textContent = money(total);
  });
  const sumEl = document.getElementById('sum');
  const grandEl = document.getElementById('grand');
  if (sumEl) sumEl.textContent = money(sum);
  const discount = Number(document.getElementById('disc')?.value || 0);
  if (grandEl) grandEl.textContent = money(Math.max(0, sum - discount));
};
window.saveInvoice = async () => {
  try {
    const items = $$('.items tbody tr').map(tr => ({
      name: $('.n', tr)?.value || 'محصول',
      qty: Number($('.q', tr)?.value || 0),
      price: Number($('.pr', tr)?.value || 0),
      cost: Number(tr.dataset.cost || 0)
    })).filter(x => x.name && x.qty > 0);
    if (!items.length) return alert('حداقل یک کالا وارد کنید');
    const result = await api('/api/orders', {method:'POST', body:JSON.stringify({
      customer_id: document.getElementById('cust')?.value || null,
      customer_name: document.getElementById('cn')?.value || '',
      customer_phone: document.getElementById('cp')?.value || '',
      customer_address: document.getElementById('ca')?.value || '',
      items,
      discount: Number(document.getElementById('disc')?.value || 0)
    })});
    await load();
    alert(`فاکتور ${result.invoice_no} ثبت شد`);
    if (confirm('برای چاپ ارسال شود؟')) {
      const printed = await api(`/api/orders/${result.id}/print`, {method:'POST', body:JSON.stringify(printOpts())});
      if (!printed.ok && printed.invoice_url) window.open(printed.invoice_url, '_blank');
      else if (printed.ok) alert('به چاپگر ارسال شد');
    }
    show('orders');
  } catch (e) { alert(e.message); }
};

const printOpts = () => ({ paper: document.getElementById('pp_paper')?.value || data.settings.print_paper || 'A4', bw: (document.getElementById('pp_bw') ? (document.getElementById('pp_bw').checked ? 1 : 0) : Number(data.settings.print_bw ?? 1)) });
const printBar = () => `<div class="row no-print" style="margin-bottom:10px;align-items:center"><b>گزینه‌های چاپ:</b>
  <select id="pp_paper"><option value="A4" ${(data.settings.print_paper||'A4')==='A4'?'selected':''}>A4</option><option value="A5" ${data.settings.print_paper==='A5'?'selected':''}>A5</option></select>
  <label><input type="checkbox" id="pp_bw" ${String(data.settings.print_bw??'1')==='1'?'checked':''}> سیاه‌وسفید</label></div>`;

function products() {
  appEl.innerHTML = `
    <div class="card"><h2>محصولات</h2>
      <div class="row">
        <div class="field"><label>نام</label><input id="pn"></div>
        <div class="field"><label>دسته</label><input id="pc" value="کوکی"></div>
        <div class="field"><label>واحد</label><input id="pu" value="عدد"></div>
        <div class="field"><label>قیمت فروش</label><input id="pp" type="number" min="0"></div>
        <div class="field"><label>بهای تمام‌شده</label><input id="pco" type="number" min="0"></div>
        <button onclick="addP()">افزودن</button>
      </div>
    </div>
    <div class="card"><div class="table-wrap"><table class="table"><thead><tr><th>نام</th><th>دسته</th><th>واحد</th><th>فروش</th><th>هزینه</th><th>عملیات</th></tr></thead><tbody>
      ${data.products.map(p => `<tr><td>${esc(p.name)}</td><td>${esc(p.category)}</td><td>${esc(p.unit)}</td><td>${money(p.price)}</td><td>${money(p.cost)}</td><td><button onclick="editP(${p.id})">ویرایش</button> <button class="danger" onclick="delP(${p.id})">حذف</button></td></tr>`).join('')}
    </tbody></table></div></div>`;
}
window.addP = async () => {
  try {
    const name = document.getElementById('pn').value.trim();
    if (!name) return alert('نام محصول را وارد کنید');
    await api('/api/products',{method:'POST',body:JSON.stringify({name,category:document.getElementById('pc').value,unit:document.getElementById('pu').value,price:Number(document.getElementById('pp').value||0),cost:Number(document.getElementById('pco').value||0)})});
    await load(); products();
  } catch(e) { alert(e.message); }
};
window.delP = async id => { if (!confirm('این محصول حذف شود؟')) return; try { await api(`/api/products/${id}`,{method:'DELETE'}); await load(); products(); } catch(e){alert(e.message);} };
window.editP = async id => {
  const p = data.products.find(x => x.id === id); if (!p) return;
  const name = prompt('نام محصول', p.name); if (name === null) return;
  const price = prompt('قیمت فروش', p.price); if (price === null) return;
  const cost = prompt('بهای تمام‌شده', p.cost); if (cost === null) return;
  try { await api(`/api/products/${id}`,{method:'PUT',body:JSON.stringify({...p,name,price:Number(price),cost:Number(cost)})}); await load(); products(); } catch(e){alert(e.message);}
};

function ingredients() {
  appEl.innerHTML=`<div class="card"><div class="section-title"><h2>مواد اولیه و قیمت بازار</h2><span>BetterBite</span></div>
  <div class="row"><div class="field"><label>نام ماده</label><input id="inm" placeholder="مثلاً آرد قنادی"></div><div class="field"><label>واحد قیمت</label><input id="inu" value="گرم"></div><div class="field"><label>قیمت دستی (تومان)</label><input id="inp" type="number" min="0"></div><div class="field"><label>مقدار خرید</label><input id="inq" type="number" value="1" min="0.0001"></div><button onclick="addI()">افزودن</button></div>
  <div class="toolbar"><button onclick="gemini()">بروزرسانی قیمت از سایت‌های ایرانی + Gemini</button></div><div id="gemBox"></div></div>
  <div class="card"><div class="table-wrap"><table class="table"><thead><tr><th>ماده</th><th>واحد</th><th>قیمت فعلی</th><th>منبع</th><th>حالت</th><th>آخرین بروزرسانی</th><th>عملیات</th></tr></thead><tbody>
  ${data.ingredients.map(i=>`<tr><td>${esc(i.name)}</td><td>${esc(i.unit)}</td><td><b>${money(i.price)}</b></td><td>${esc(i.price_source||'—')}</td><td>${i.pricing_mode==='manual'?'<span class="pill">دستی</span>':'<span class="pill">خودکار</span>'}</td><td>${esc(i.price_updated_at||'—')}</td><td><button onclick="editI(${i.id})">ویرایش</button> <button class="danger" onclick="delI(${i.id})">حذف</button></td></tr>`).join('')}
  </tbody></table></div></div>`;
}
window.addI=async()=>{try{const name=document.getElementById('inm').value.trim();if(!name)return alert('نام ماده را وارد کنید');const price=Number(document.getElementById('inp').value||0);await api('/api/ingredients',{method:'POST',body:JSON.stringify({name,unit:document.getElementById('inu').value,price,quantity:Number(document.getElementById('inq').value||1),pricing_mode:price?'manual':'auto'})});await load();ingredients();}catch(e){alert(e.message)}};
window.upI=async(id,value,mode='manual',source='manual')=>{try{const i=data.ingredients.find(x=>x.id===id);if(!i)return;await api(`/api/ingredients/${id}`,{method:'PUT',body:JSON.stringify({...i,price:Number(value||0),pricing_mode:mode,price_source:source})});await load();ingredients();}catch(e){alert(e.message)}};
window.editI=id=>{const i=data.ingredients.find(x=>x.id===id);if(!i)return;const v=prompt('قیمت جدید به تومان — این قیمت دستی خواهد بود',i.price);if(v!==null)upI(id,v,'manual','manual');};
window.delI=async id=>{if(!confirm('این ماده حذف شود؟'))return;try{await api(`/api/ingredients/${id}`,{method:'DELETE'});await load();ingredients();}catch(e){alert(e.message)}};
window.gemini=async()=>{try{const x=await api('/api/gemini/update-prices',{method:'POST'});const items=(x.items||[]).filter(i=>i.id);const box=document.getElementById('gemBox');if(!items.length){box.innerHTML='<p class="muted">داده‌ای برای بروزرسانی پیدا نشد.</p>';return}box.innerHTML=`<div class="card"><h3>پیشنهاد قیمت رایج</h3><p class="muted">ارزان‌ترین و گران‌ترین قیمت معیار نیستند. قیمت‌ها از چند سایت ایرانی جمع و نرمال شده‌اند.</p><div class="table-wrap"><table class="table"><thead><tr><th>ماده</th><th>قیمت فعلی</th><th>قیمت رایج</th><th>اعتماد</th><th>داده بازار</th><th>عملیات</th></tr></thead><tbody>${items.map(i=>`<tr><td>${esc(i.name)}</td><td>${money(i.old_price)}</td><td><b>${i.common_price?money(i.common_price):'—'}</b></td><td>${i.manual?'دستی':Math.round(Number(i.confidence||0)*100)+'%'}</td><td>${Number(i.offers?.length||0)} قیمت</td><td>${i.manual?'بدون تغییر':i.common_price?`<button onclick="upI(${i.id},${Number(i.common_price)},'auto','web+gemini')">اعمال</button>`:'—'}</td></tr>`).join('')}</tbody></table></div></div>`;}catch(e){alert(e.message)}};

function recipeItem() {
  return `<div class="row ri"><select class="ing"><option value="">ماده اولیه</option>${data.ingredients.map(i=>`<option value="${i.id}">${esc(i.name)}</option>`).join('')}</select><input class="ia" type="number" value="0" min="0" placeholder="مقدار مصرف"><button class="danger" onclick="this.parentElement.remove()">×</button></div>`;
}
function recipes() {
  appEl.innerHTML = `<div class="card"><h2>محاسبه بهای تمام‌شده</h2><p class="muted">مواد، وزن تولید و سود را وارد کنید.</p>
    <div class="row"><input id="rn" placeholder="نام دستور"><input id="ry" type="number" value="10" min="1" placeholder="تعداد خروجی"><input id="rw" type="number" value="0" min="0" placeholder="وزن کل (گرم)"><input id="rtw" type="number" value="0" min="0" placeholder="وزن هر کوکی/برش"><input id="rp" type="number" value="30" placeholder="درصد سود"></div>
    <div id="ri">${recipeItem()}</div><button onclick="addRI()">+ ماده</button> <button onclick="saveR()">ذخیره دستور</button>
  </div><div class="card"><h3>دستورهای ذخیره‌شده</h3><div class="table-wrap"><table class="table"><thead><tr><th>نام</th><th>خروجی</th><th>هزینه کل</th><th>هزینه هر واحد</th><th>قیمت پیشنهادی</th><th>عملیات</th></tr></thead><tbody>
    ${data.recipes.map(r => `<tr><td>${esc(r.name)}</td><td>${Number(r.pieces).toLocaleString('fa-IR',{maximumFractionDigits:1})}</td><td>${money(r.ingredient_cost)}</td><td>${money(r.cost_per_unit)}</td><td><b>${money(r.suggested_price)}</b></td><td><button onclick="r2p(${r.id})">ساخت محصول</button> <button class="danger" onclick="delR(${r.id})">حذف</button></td></tr>`).join('')}
  </tbody></table></div></div>`;
}
window.delR = async id => { if(!confirm('این دستور حذف شود؟'))return; try{ await api(`/api/recipes/${id}`,{method:'DELETE'}); await load(); recipes(); }catch(e){alert(e.message);} };
window.r2p = async id => { try{ await api(`/api/recipes/${id}/to-product`,{method:'POST'}); await load(); alert('به محصولات اضافه شد'); }catch(e){alert(e.message);} };
window.addRI = () => { const box=document.getElementById('ri'); if(box)box.insertAdjacentHTML('beforeend',recipeItem()); };
window.saveR = async () => { try { const name=document.getElementById('rn').value.trim(); if(!name)return alert('نام دستور را وارد کنید'); const items=$$('.ri').map(x=>({ingredient_id:Number($('.ing',x).value),amount:Number($('.ia',x).value||0)})).filter(x=>x.ingredient_id&&x.amount>0); if(!items.length)return alert('حداقل یک ماده وارد کنید'); await api('/api/recipes',{method:'POST',body:JSON.stringify({name,yield_count:Number(document.getElementById('ry').value||1),yield_weight:Number(document.getElementById('rw').value||0),target_weight:Number(document.getElementById('rtw').value||0),profit_percent:Number(document.getElementById('rp').value||0),items})}); await load(); recipes(); } catch(e){alert(e.message);} };

function customers() {
  appEl.innerHTML = `<div class="card"><h2>مشتریان</h2><div class="row"><input id="cname" placeholder="نام"><input id="cphone" placeholder="تلفن"><input id="caddr" placeholder="آدرس"><button onclick="addC()">ثبت مشتری</button></div></div>
  <div class="card"><div class="table-wrap"><table class="table"><thead><tr><th>نام</th><th>تلفن</th><th>آدرس</th><th>سابقه</th><th>عملیات</th></tr></thead><tbody>${data.customers.map(c=>`<tr><td>${esc(c.name)}</td><td>${esc(c.phone)}</td><td>${esc(c.address)}</td><td><button onclick="historyC(${c.id})">مشاهده</button></td><td><button onclick="editC(${c.id})">ویرایش</button> <button class="danger" onclick="delC(${c.id})">حذف</button></td></tr>`).join('')}</tbody></table></div></div>`;
}
window.addC = async()=>{try{const name=document.getElementById('cname').value.trim();if(!name)return alert('نام مشتری را وارد کنید');await api('/api/customers',{method:'POST',body:JSON.stringify({name,phone:document.getElementById('cphone').value,address:document.getElementById('caddr').value})});await load();customers();}catch(e){alert(e.message);}};
window.editC = async id => { const c=data.customers.find(x=>x.id===id); if(!c)return; const name=prompt('نام',c.name); if(name===null)return; const phone=prompt('تلفن',c.phone||''); if(phone===null)return; const address=prompt('آدرس',c.address||''); if(address===null)return; try{ await api(`/api/customers/${id}`,{method:'PUT',body:JSON.stringify({name,phone,address})}); await load(); customers(); }catch(e){alert(e.message);} };
window.delC = async id => { if(!confirm('این مشتری حذف شود؟ (فاکتورها حفظ می‌شوند)'))return; try{ await api(`/api/customers/${id}`,{method:'DELETE'}); await load(); customers(); }catch(e){alert(e.message);} };
window.historyC = async id=>{try{const x=await api(`/api/customers/${id}/orders`);alert(x.map(o=>`${o.invoice_no} — ${money(o.total)} — ${o.status}`).join('\n')||'سابقه‌ای نیست');}catch(e){alert(e.message);}};

function orders() {
  appEl.innerHTML = `<div class="card"><h2>سوابق فاکتورها</h2>${printBar()}<div class="table-wrap"><table class="table"><thead><tr><th>شماره</th><th>مشتری</th><th>مبلغ</th><th>وضعیت</th><th>تاریخ</th><th>عملیات</th></tr></thead><tbody>
  ${data.orders.map(o=>`<tr class="${o.ignored?'muted':''}" style="${o.ignored?'opacity:.5;text-decoration:line-through':''}"><td>${esc(o.invoice_no)}</td><td>${esc(o.customer_name||'-')}</td><td>${money(o.total)}</td><td>${esc(o.status)}</td><td>${fdate(o.created_at)}</td><td><button onclick="printO(${o.id})">چاپ</button> <button class="secondary" onclick="openInv(${o.id},1)">چاپ مرورگر</button> <button class="secondary" onclick="openInv(${o.id},0)">پیش‌نمایش</button> ${o.ignored?`<button onclick="restoreO(${o.id})">بازگردانی</button>`:`<button class="danger" onclick="ignoreO(${o.id})">نادیده</button>`}</td></tr>`).join('')}
  </tbody></table></div></div>`;
}
window.openInv=(id,pr)=>{const o=printOpts();window.open(`/api/orders/${id}/invoice?print=${pr}&paper=${o.paper}&bw=${o.bw}`,'_blank');};
window.printO = async id=>{try{const x=await api(`/api/orders/${id}/print`,{method:'POST',body:JSON.stringify(printOpts())});if(!x.ok&&x.invoice_url)window.open(x.invoice_url,'_blank');else if(x.ok)alert('به چاپگر ارسال شد');}catch(e){alert(e.message);}};
window.restoreO = async id=>{try{await api(`/api/orders/${id}/restore`,{method:'POST'});await load();orders();}catch(e){alert(e.message);}};
window.ignoreO = async id=>{if(!confirm('این فاکتور نادیده گرفته شود؟'))return;try{await api(`/api/orders/${id}/ignore`,{method:'POST'});await load();orders();}catch(e){alert(e.message);}};

async function reports(){try{const r=await api('/api/reports');appEl.innerHTML=`<div class="grid">${Object.entries(r).map(([k,v])=>`<div class="card"><h3>${esc(k)}</h3><div class="stat">${money(v.sales)}</div><div>فروش</div><hr><b>${money(v.profit)}</b> سود تقریبی<br>${v.orders} فاکتور</div>`).join('')}</div><div class="card"><p class="muted">سود بر اساس بهای تمام‌شده ذخیره‌شده در اقلام فاکتور محاسبه می‌شود.</p></div>`;}catch(e){appEl.innerHTML=`<div class="card bad">${esc(e.message)}</div>`;}}

function settings(){
  const logo = data.settings.logo || '/static/bakora-logo.png';
  appEl.innerHTML = `<div class="card"><h2>تنظیمات فروشگاه</h2><div class="grid">
    <div class="field"><label>نام فروشگاه</label><input id="sn" value="${esc(data.settings.shop_name||'BAKORA')}"></div>
    <div class="field"><label>تلفن</label><input id="sp" value="${esc(data.settings.shop_phone||'')}"></div>
    <div class="field"><label>آدرس</label><input id="sa" value="${esc(data.settings.shop_address||'')}"></div>
    <div class="field"><label>واحد پول</label><input id="sc" value="${esc(data.settings.currency||'تومان')}"></div>
    <div class="field"><label>متن پایین فاکتور</label><input id="sf" value="${esc(data.settings.invoice_footer||'')}"></div>
    <div class="field"><label>اندازه کاغذ پیش‌فرض</label><select id="spaper"><option value="A4" ${(data.settings.print_paper||'A4')==='A4'?'selected':''}>A4</option><option value="A5" ${data.settings.print_paper==='A5'?'selected':''}>A5</option></select></div>
    <div class="field"><label>رنگ چاپ</label><select id="sbw"><option value="1" ${String(data.settings.print_bw??'1')==='1'?'selected':''}>سیاه‌وسفید</option><option value="0" ${String(data.settings.print_bw)==='0'?'selected':''}>رنگی</option></select></div>
    <div class="field"><label>نام چاپگر (خالی = پیش‌فرض)</label><input id="spn" value="${esc(data.settings.printer_name||'')}"></div>
    <div class="field"><label>پروکسی SOCKS5 فقط برای Gemini API</label><input id="gproxy" placeholder="مثلاً socks5h://127.0.0.1:10808" value="${esc(data.settings.gemini_proxy||'')}"></div>
    <div class="field"><label>Gemini API Key</label><input id="gk" type="password" placeholder="${data.settings.gemini_key_set?'ذخیره شده — برای تغییر مقدار جدید وارد کنید':''}"></div>
  </div><button onclick="saveS()">ذخیره تنظیمات</button><hr>
  <h3>لوگوی BAKORA</h3><div class="logo-settings"><img id="logoPreview" src="${esc(logo)}" alt="لوگوی BAKORA"><div><input type="file" id="logoFile" accept=".png,.jpg,.jpeg,.webp,.svg"><button onclick="uploadLogo()">آپلود لوگو</button></div></div>
  <h3>اجرای خودکار سرور</h3>
  <div class="card service-box">
    <p class="muted">سرویس ویندوزی BetterBite قبل از ورود کاربر به ویندوز اجرا می‌شود و با روشن شدن سرور بالا می‌آید.</p>
    <div id="svcStatus" class="pill">در حال بررسی وضعیت...</div>
    <div class="row service-actions">
      <button onclick="serviceAction('install')">نصب و اجرای سرویس</button>
      <button class="secondary" onclick="serviceAction('start')">شروع</button>
      <button class="secondary" onclick="serviceAction('restart')">راه‌اندازی مجدد</button>
      <button class="secondary" onclick="serviceAction('stop')">توقف</button>
      <button class="danger" onclick="serviceAction('uninstall')">حذف سرویس</button>
    </div>
    <small class="muted">نصب/حذف سرویس نیاز به اجرای سرور با دسترسی Administrator دارد. نام سرویس: BetterBiteServer</small>
  </div>
  <h3>چاپگرهای کامپیوتر</h3><button onclick="printers()">خواندن چاپگرها</button><div id="plist"></div>
  </div>`;
  serviceStatus();
}
window.saveS=async()=>{try{await api('/api/settings',{method:'POST',body:JSON.stringify({shop_name:document.getElementById('sn').value,shop_phone:document.getElementById('sp').value,shop_address:document.getElementById('sa').value,currency:document.getElementById('sc').value,invoice_footer:document.getElementById('sf').value,gemini_key:document.getElementById('gk').value,gemini_proxy:document.getElementById('gproxy').value,printer_name:document.getElementById('spn')?.value||'',print_paper:document.getElementById('spaper').value,print_bw:document.getElementById('sbw').value})});await load();alert('تنظیمات ذخیره شد');settings();}catch(e){alert(e.message);}};
window.uploadLogo=async()=>{try{const input=document.getElementById('logoFile');const file=input?.files?.[0];if(!file)return alert('ابتدا فایل لوگو را انتخاب کنید');const fd=new FormData();fd.append('file',file);const result=await api('/api/logo',{method:'POST',body:fd});await load();alert('لوگو با موفقیت اعمال شد');settings();const preview=document.getElementById('logoPreview');if(preview)preview.src=result.url;}catch(e){alert(e.message);}};
window.serviceStatus=async()=>{try{const x=await api('/api/service');const el=document.getElementById('svcStatus');if(!el)return;el.textContent=x.installed?(x.running?'● سرویس فعال و در حال اجرا':'○ سرویس نصب است ولی متوقف است'):'○ سرویس نصب نشده';el.className='pill '+(x.running?'good':'');}catch(e){const el=document.getElementById('svcStatus');if(el)el.textContent='سرویس فقط روی Windows Server قابل استفاده است';}};
window.serviceAction=async action=>{try{const labels={install:'نصب و اجرای سرویس',uninstall:'حذف سرویس',start:'شروع سرویس',stop:'توقف سرویس',restart:'راه‌اندازی مجدد'};if(!confirm(`${labels[action]||action} انجام شود؟`))return;const x=await api(`/api/service/${action}`,{method:'POST'});alert(x.detail||'انجام شد');await serviceStatus();}catch(e){alert(e.message);await serviceStatus();}};
window.printers=async()=>{try{const x=await api('/api/printers');document.getElementById('plist').innerHTML=(x.printers||[]).map(p=>`<div class="pill" style="cursor:pointer" onclick="document.getElementById('spn').value=this.textContent">${esc(p)}</div>`).join(' ')+(x.default?`<p>پیش‌فرض: <b>${esc(x.default)}</b></p>`:'');}catch(e){alert(e.message);}};

window.addEventListener('error', event => console.error('BAKORA JS error:', event.error || event.message));

load().then(()=>show('dashboard')).catch(e=>{console.error(e);appEl.innerHTML=`<div class="card bad"><h3>اتصال به برنامه برقرار نشد</h3><p>${esc(e.message)}</p><p>سرور BAKORA را اجرا کنید و صفحه را دوباره باز کنید.</p></div>`;});
