# BAKORA — مدیریت فاکتور و حسابداری شیرینی‌فروشی

نسخه‌ی اولیه‌ی قابل اجرا برای شبکه‌ی محلی:
- وب‌اپ RTL و فارسی
- صدور فاکتور شبیه نمونه‌ی ارسالی
- لوگوی دلخواه
- محصولات سریع
- مشتری و سوابق خرید
- مواد اولیه و محاسبه بهای تمام‌شده
- محاسبه قیمت هر کوکی/برش بر اساس وزن، تعداد و درصد سود
- گزارش سود روز/هفته/ماه/کل
- نادیده‌گرفتن سفارش
- ذخیره اطلاعات در SQLite
- سرویس روی کامپیوتر و دسترسی از موبایل‌های همان شبکه
- چاپ از سمت کامپیوتر میزبان
- تنظیم API Key جمینای برای برآورد/به‌روزرسانی قیمت مواد اولیه

## اجرا روی ویندوز

1. Python 3.11+ نصب باشد.
2. داخل پوشه:
   `py -m venv .venv`
3. فعال‌سازی:
   `.venv\Scripts\activate`
4. نصب:
   `pip install -r requirements.txt`
5. اجرا:
   `python run.py`
6. روی کامپیوتر:
   `http://127.0.0.1:8787`
7. روی موبایل متصل به همان Wi‑Fi:
   `http://IP-COMPUTER:8787`

برای پیدا کردن IP:
`ipconfig`

برای دسترسی شبکه، اگر Windows Firewall پرسید، دسترسی Private Network را Allow کنید.

## چاپ
اپ روی کامپیوتر میزبان فاکتور را تولید می‌کند و در صورت وجود Microsoft Edge و pywin32 می‌تواند آن را به چاپگر پیش‌فرض سیستم ارسال کند.
اگر چاپ خودکار در محیطی کار نکرد، از دکمه «چاپ از مرورگر» استفاده کنید.

## Gemini
در تنظیمات، API Key جمینای را وارد کنید. کلید فقط روی سرور محلی ذخیره می‌شود.
این قابلیت برای پیشنهاد/میانگین‌سازی قیمت‌هاست و قیمت نهایی را خودکار بدون تأیید کاربر تغییر نمی‌دهد.

نکته: برای قیمت واقعی بازار، بهتر است بعداً منبع قیمت یا API مشخصی هم اضافه شود؛ Gemini به‌تنهایی منبع قیمت بازار نیست.

## تنظیمات چاپ (لیزری HP M506)
در تنظیمات اندازه کاغذ (A4/A5)، سیاه‌وسفید/رنگی و نام چاپگر را ذخیره کنید؛ در صفحه فاکتور و سوابق هم می‌توان برای هر چاپ جداگانه تغییرشان داد. چاپ ترموکس پشتیبانی نمی‌شود.

## BetterBite price updater

The UI is branded as BetterBite and the ingredient pricing flow now supports:
- local scraping of configured Iranian stores/pages;
- optional SOCKS5/SOCKS5H proxy for both scraping and Gemini requests;
- normalization to the ingredient's current purchase quantity/unit;
- common-market pricing instead of choosing the minimum/maximum offer;
- manual price override, which is never overwritten by automatic updates;
- Gemini receives scraped Iranian offers and selects the common market cluster rather than inventing a price.

Set the Gemini API key and proxy in **Settings**. Example proxy: `socks5h://127.0.0.1:10808`.

Default sources can be changed in the `price_sources` setting/API. The default sources are Iranian bakery/ingredient shops and should be reviewed if a site changes its search URL or markup.

### اجرای خودکار روی Windows Server
از بخش تنظیمات می‌توان `BetterBiteServer` را به‌عنوان Windows Service نصب کرد. سرویس با Startup Type = Automatic تنظیم می‌شود و قبل از Login ویندوز اجرا خواهد شد. برای نصب/حذف سرویس، فرآیند BetterBite باید با دسترسی Administrator اجرا شود. در صورت Crash نیز Windows برای سرویس restart تنظیم می‌شود.
