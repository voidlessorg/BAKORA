@echo off
cd /d "%~dp0"
echo ==========================================
echo              BAKORA
echo        Bakery Management System
echo ==========================================
echo.

if not exist .venv (
  echo [1/3] Creating virtual environment...
  py -m venv .venv
  if errorlevel 1 (
    echo.
    echo ERROR: Python virtual environment could not be created.
    pause
    exit /b 1
  )
)

call .venv\Scripts\activate.bat
if errorlevel 1 (
  echo ERROR: Could not activate virtual environment.
  pause
  exit /b 1
)

echo [2/3] Installing/updating dependencies...
python -m pip install --upgrade pip
if errorlevel 1 (
  echo.
  echo ERROR: pip upgrade failed.
  pause
  exit /b 1
)

python -m pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo ==========================================
  echo ERROR: Dependency installation failed.
  echo ==========================================
  echo Check the error above and try again.
  pause
  exit /b 1
)

echo.
echo [3/3] Starting BAKORA...
echo Open: http://127.0.0.1:8787
echo.
python run.py
pause
