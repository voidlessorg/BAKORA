"""BetterBite Windows Service.
Runs the FastAPI/Uvicorn server before any user logs in.
Windows-only; requires pywin32 and Administrator privileges to install/remove.
"""
import os, sys
from pathlib import Path

BASE = Path(__file__).resolve().parent
os.chdir(BASE)

import servicemanager
import win32event
import win32service
import win32serviceutil

SERVICE_NAME = "BetterBiteServer"
DISPLAY_NAME = "BetterBite Server"
DESCRIPTION = "BetterBite bakery management server (FastAPI/Uvicorn)."


class BetterBiteService(win32serviceutil.ServiceFramework):
    _svc_name_ = SERVICE_NAME
    _svc_display_name_ = DISPLAY_NAME
    _svc_description_ = DESCRIPTION

    def __init__(self, args):
        win32serviceutil.ServiceFramework.__init__(self, args)
        self.stop_event = win32event.CreateEvent(None, 0, 0, None)
        self.is_stopping = False
        self.server = None

    def SvcStop(self):
        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        self.is_stopping = True
        if self.server is not None:
            self.server.should_exit = True
        win32event.SetEvent(self.stop_event)

    def SvcDoRun(self):
        servicemanager.LogInfoMsg(f"{DISPLAY_NAME} starting")
        self.main()

    def main(self):
        try:
            import uvicorn
            from app.server import app
            config = uvicorn.Config(
                app,
                host="0.0.0.0",
                port=8787,
                log_level="info",
                reload=False,
                access_log=True,
            )
            server = uvicorn.Server(config)
            self.server = server
            # Run uvicorn in this service process. The service manager owns its lifetime.
            server.run()
        except Exception as exc:
            servicemanager.LogErrorMsg(f"{DISPLAY_NAME} crashed: {exc!r}")
            raise


if __name__ == "__main__":
    win32serviceutil.HandleCommandLine(BetterBiteService)
