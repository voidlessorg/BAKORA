@echo off
cd /d "%~dp0"
if not exist .venv (
  echo First run START.bat to install dependencies.
  pause
  exit /b 1
)
call .venv\Scripts\activate
python run.py
